package hust.cs.javacourse.search.parse.impl;

import hust.cs.javacourse.search.index.AbstractTerm;
import hust.cs.javacourse.search.index.AbstractTermTuple;
import hust.cs.javacourse.search.index.impl.Term;
import hust.cs.javacourse.search.index.impl.TermTuple;
import hust.cs.javacourse.search.parse.AbstractTermTupleScanner;
import hust.cs.javacourse.search.util.Config;
import hust.cs.javacourse.search.util.StringSplitter;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class TermTupleScanner extends AbstractTermTupleScanner {
    private int position = 0;
    private List<String> list;
    private StringSplitter stringSplitter = new StringSplitter();

    @Override
    public void close() {
        super.close();
    }
    public TermTupleScanner(){
        list = new ArrayList<>();
        stringSplitter.setSplitRegex(Config.STRING_SPLITTER_REGEX);
    }
    public TermTupleScanner(BufferedReader input) {
        super(input);
        list = new ArrayList<>();
        stringSplitter.setSplitRegex(Config.STRING_SPLITTER_REGEX);

    }

    @Override
    public AbstractTermTuple next() {
        try{
            if(list.isEmpty())
            {
                String temp=null;
                StringBuffer  buffer = new StringBuffer();
                while((temp = input.readLine())!=null)
                {
                    buffer.append(temp);
                    //readline会去掉换行符
                    buffer.append("\n");
                }
                temp=buffer.toString().trim();
                temp = temp.toLowerCase();
                list = stringSplitter.splitByRegex(temp);
            }
            if(list.size()==0)return null;
            AbstractTerm term = new Term(list.get(0));
            list.remove(0);
            return new TermTuple(term,position++);
        }catch (IOException e)
        {
            e.printStackTrace();
        }
        return null;
    }
}
