package hust.cs.javacourse.search.parse.impl;

import hust.cs.javacourse.search.index.AbstractTermTuple;
import hust.cs.javacourse.search.parse.AbstractTermTupleFilter;
import hust.cs.javacourse.search.parse.AbstractTermTupleStream;
import hust.cs.javacourse.search.util.StopWords;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;
//停用词过滤器
public class StopWordTermTupleFilter extends AbstractTermTupleFilter {
    private List<String> stopWords = Arrays.asList(StopWords.STOP_WORDS);
    public StopWordTermTupleFilter(AbstractTermTupleStream input) {
        super(input);
    }

    //设置过滤词
    public void setStopWords(List<String> stopWords) {
        this.stopWords = stopWords;
    }
    public void setStopWords(String[] stopWords) {
        this.stopWords =Arrays.asList(stopWords);
    }
    @Override
    public AbstractTermTuple next() throws FileNotFoundException {
        AbstractTermTuple termTuple = input.next();
        if(termTuple==null)return null;
        while(stopWords.contains(termTuple.term.getContent())){
            termTuple=input.next();
            if(termTuple==null)return null;
        }
        return termTuple;
    }
}
