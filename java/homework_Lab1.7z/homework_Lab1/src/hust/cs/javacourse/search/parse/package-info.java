/**
 * hust.cs.javacourse.search.parse包里定义了文档解析、分词，单词过滤有关的抽象类.学生需要实现这些抽象类的具体子类
 */
package hust.cs.javacourse.search.parse;