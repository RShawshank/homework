package hust.cs.javacourse.search.query.impl;

import hust.cs.javacourse.search.index.AbstractPosting;
import hust.cs.javacourse.search.index.AbstractTerm;
import hust.cs.javacourse.search.query.AbstractHit;

import java.util.Map;

public class Hit extends AbstractHit {
    public Hit(){
    }
    public Hit (int docId,String docPath)
    {
        super(docId, docPath);
    }
    public Hit(int docId, String docPath, Map<AbstractTerm, AbstractPosting> termPostingMapping) {
        super(docId, docPath, termPostingMapping);
    }

    @Override
    public double getScore() {
        return this.score;
    }

    @Override
    public int getDocId() {
        return this.docId;
    }

    @Override
    public String getContent() {
        return this.content;
    }

    @Override
    public String getDocPath() {
        return this.docPath;
    }

    @Override
    public void setContent(String content) {
        this.content=content;
    }

    @Override
    public void setScore(double score) {
        this.score=score;
    }

    @Override
    public Map<AbstractTerm, AbstractPosting> getTermPostingMapping() {
        return this.termPostingMapping;
    }

    @Override
    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("docId:"+this.docId);
        buffer.append("\ndocPath:"+this.docPath);
        buffer.append("\ncontent:"+this.content);
        buffer.append("\nscore:"+this.score);
        buffer.append("\ntermPostingMapping:"+this.termPostingMapping);
        return buffer.toString();
    }

    @Override
    public int compareTo(AbstractHit o) {
        return (int)(this.score-o.getScore());
    }
}
