package hust.cs.javacourse.search.query.impl;
import hust.cs.javacourse.search.index.AbstractPosting;
import hust.cs.javacourse.search.index.AbstractPostingList;
import hust.cs.javacourse.search.index.AbstractTerm;
import hust.cs.javacourse.search.index.impl.Posting;
import hust.cs.javacourse.search.index.impl.Term;
import hust.cs.javacourse.search.query.AbstractHit;
import hust.cs.javacourse.search.query.AbstractIndexSearcher;
import hust.cs.javacourse.search.query.Sort;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class IndexSearcher extends AbstractIndexSearcher {
    @Override
    public void open(String indexFile) {
        index.load(new File(indexFile));
        index.optimize();
    }

    @Override
    public AbstractHit[] search(AbstractTerm queryTerm, Sort sorter) {
        AbstractPostingList postingList = index.search(queryTerm);
        if(postingList==null)return null;
        List<AbstractHit> list = new ArrayList<>();
        for(int i = 0 ; i < postingList.size() ; i++)
        {
            AbstractPosting posting = postingList.get(i);
            String path = index.getDocName(posting.getDocId());
            HashMap<AbstractTerm,AbstractPosting> map = new HashMap<>();
            map.put(queryTerm,posting);
            AbstractHit hit = new Hit(posting.getDocId(),path,map);
            hit.setScore(sorter.score(hit));
            list.add(hit);
        }
        sorter.sort(list);
        return list.toArray(new AbstractHit[0]);
    }
//根据两个检索词进行检索
    @Override
    public AbstractHit[] search(AbstractTerm queryTerm1, AbstractTerm queryTerm2, Sort sorter, LogicalCombination combine) {
        AbstractPostingList postingList1 = index.search(queryTerm1);
        AbstractPostingList postingList2 = index.search(queryTerm2);
        int length1=0;
        int length2=0;
        if(postingList1 == null && postingList2 == null)
            return null;
        List<AbstractHit> list = new ArrayList<>();
        if(postingList1!=null)
        {
            length1=postingList1.size();
        }
        if(postingList2!=null)
        {
            length2=postingList2.size();
        }

        int i = 0 , j = 0;
        Posting Nothing = new Posting(-1,-1,null);
        while (i < length1 || j < length2){
            AbstractPosting posting1=null;
            AbstractPosting posting2=null;
            if(i<length1)
            {
                posting1=postingList1.get(i);
            }
            else
            {
                posting1=Nothing;
            }
            if(j<length2)
            {
                posting2=postingList2.get(j);
            }
            else
            {
                posting2=Nothing;
            }
            int docId1 = posting1.getDocId();
            int docId2 = posting2.getDocId();
            if(docId1 == docId2 && docId1 != -1)
            {
                String path = index.getDocName(docId1);
                HashMap<AbstractTerm,AbstractPosting> map = new HashMap<>();
                map.put(queryTerm1,posting1);
                map.put(queryTerm2,posting2);
                AbstractHit hit = new Hit(docId1,path,map);
                hit.setScore(sorter.score(hit));
                list.add(hit);
                i++;
                j++;
            }
            else if(docId1 < docId2 && docId1 != -1 ){  //或
                if(combine == LogicalCombination.OR) {
                    String path = index.getDocName(docId1);
                    HashMap<AbstractTerm, AbstractPosting> map = new HashMap<>();
                    map.put(queryTerm1, posting1);
                    AbstractHit hit = new Hit(docId1, path, map);
                    hit.setScore(sorter.score(hit));
                    list.add(hit);
                }
                i++;
            }
            else {
                if(combine == LogicalCombination.OR && docId2 != -1){
                    String path = index.getDocName(docId2);
                    HashMap<AbstractTerm,AbstractPosting> map = new HashMap<>();
                    map.put(queryTerm2,posting2);
                    AbstractHit hit = new Hit(docId2,path,map);
                    hit.setScore(sorter.score(hit));
                    list.add(hit);
                }
                j++;
            }
        }
        sorter.sort(list);
        return list.toArray(new AbstractHit[0]);
    }
    /**
     * 根据二个相邻的检索词进行搜索
     */
    public AbstractHit[] search(AbstractTerm queryTerm1, AbstractTerm queryTerm2, Sort sorter) {
        AbstractPostingList postingList1 = index.search(queryTerm1);
        AbstractPostingList postingList2 = index.search(queryTerm2);
        if(postingList1 == null || postingList2 == null)
            return null;
        List<AbstractHit> list = new ArrayList<>();
        int length1 = postingList1.size();
        int length2 = postingList2.size();
        int i = 0 , j = 0;
        while (i < length1 && j < length2){
            AbstractPosting posting1 = postingList1.get(i);
            AbstractPosting posting2 = postingList2.get(j);
            int docId1 = posting1.getDocId(), docId2 = posting2.getDocId();
            if(docId1 == docId2 && docId1 != -1){  //且
                List<Integer> position1 = posting1.getPositions();
                List<Integer> position2 = posting2.getPositions();
                List<Integer> curPosition = new ArrayList<>();
                int pos1 = 0 ;
                int pos2 = 0;
                while (pos1 < position1.size() && pos2 < position2.size()){
                    int curPos1 = position1.get(pos1) , curPos2 = position2.get(pos2);
                    if(Math.abs(curPos1 - curPos2) == 1){
                        curPosition.add(Math.min(curPos1,curPos2));
                        pos1++;
                        pos2++;
                    }
                    else if(curPos1 < curPos2 - 2)
                        pos1++;
                    else if(curPos2 < curPos1 - 2)
                        pos2++;
                }
                if(!curPosition.isEmpty()){
                    String path = index.getDocName(docId1);
                    HashMap<AbstractTerm,AbstractPosting> map = new HashMap<>();
                    map.put(new Term(queryTerm1.getContent() + " " + queryTerm2.getContent()),new Posting(docId1,curPosition.size(),curPosition));
                    AbstractHit hit = new Hit(docId1,path,map);
                    hit.setScore(sorter.score(hit));
                    list.add(hit);
                }
                i++;
                j++;
            }
            else if(docId1 < docId2 ) //或
                i++;
            else
                j++;
        }
        sorter.sort(list);
        return list.toArray(new AbstractHit[0]);
    }
}
