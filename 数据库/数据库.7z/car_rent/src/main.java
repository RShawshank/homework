import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.SplitPane;
import javafx.stage.Stage;

import java.sql.SQLException;

public class main  {
    public static void main(String[] args) {
        Application.launch(App.class,args);
    }

}
